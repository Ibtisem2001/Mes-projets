﻿using System;
using System.Collections.Generic;

class Hangman
{
    private static readonly string[] HANGMAN_PICS = {
        "   ===   \n" +
        "         \n" +
        "         \n" +
        "         \n" +
        " +---+   ",
        "   ===   \n" +
        "    |    \n" +
        "         \n" +
        "         \n" +
        " +---+   ",
        "   ===   \n" +
        "    |    \n" +
        "    O    \n" +
        "         \n" +
        " +---+   ",
        "   ===   \n" +
        "    |    \n" +
        "    O    \n" +
        "    |    \n" +
        " +---+   ",
        "   ===   \n" +
        "    |    \n" +
        "    O    \n" +
        "   /|    \n" +
        " +---+   ",
        "   ===   \n" +
        "    |    \n" +
        "    O    \n" +
        "   /|\\   \n" +
        " +---+   ",
        "   ===   \n" +
        "    |    \n" +
        "    O    \n" +
        "   /|\\   \n" +
        "   /     \n" +
        " +---+   ",
        "   ===   \n" +
        "    |    \n" +
        "    O    \n" +
        "   /|\\   \n" +
        "   / \\   \n" +
        " +---+   "
    };

    private int incorrectAttempts;

    public Hangman()
    {
        incorrectAttempts = 0;
    }

    public void IncrementIncorrectAttempts()
    {
        incorrectAttempts++;
    }

    public bool IsGameOver()
    {
        return incorrectAttempts >= HANGMAN_PICS.Length - 1;
    }

    public void DisplayHangman()
    {
        Console.WriteLine(HANGMAN_PICS[incorrectAttempts]);
    }
}

class Program
{
    static void Main()
    {
        while (true)
        {
            Console.WriteLine("Bienvenue dans le jeu du Pendu !");
            Console.WriteLine("Dans ce jeu, l'ordinateur choisit un mot au hasard, et vous devez deviner quel est ce mot en proposant des lettres une par une.");
            Console.WriteLine("Si la lettre que vous proposez est dans le mot, elle sera affichée à sa place. Sinon, vous commencerez à dessiner le pendu.");
            Console.WriteLine("Le jeu continue jusqu'à ce que vous deviniez toutes les lettres du mot ou que le pendu soit complètement dessiné.");
            Console.WriteLine("Bonne chance !\n");


            Console.WriteLine("Cliquez pour continuer...");
            Console.ReadKey(true);
            Console.Clear(); // Nettoie la console

            StartGame();

            Console.WriteLine("Veux-tu rejouer (oui ou non) ?");
            string playAgainResponse = Console.ReadLine().ToLower();
            if (!playAgainResponse.StartsWith("o"))
            {
                break;
            }
        }

        Console.WriteLine("Merci d'avoir joué !");
    }

    static void StartGame()
    {
        List<char> correctLetters = new List<char>();
        List<char> missedLetters = new List<char>();

        Hangman hangman = new Hangman();
        string[] words = { "bob", "bad", "bed", "baleine", "elephant", "canard", "grenouille" };
        string secretWord = GetRandomWord(words);
        bool gameIsDone = false;

        while (!gameIsDone)
        {
            Console.Clear(); // Nettoie la console

            hangman.DisplayHangman();
            DisplayBoard(missedLetters, correctLetters, secretWord);

            char guess = GetGuess(missedLetters, correctLetters);

            if (secretWord.Contains(guess))
            {
                correctLetters.Add(guess);

                if (CheckWin(secretWord, correctLetters))
                {
                    Console.WriteLine($"Le mot secret est {secretWord} | Tu as gagné !");
                    gameIsDone = true;
                }
            }
            else
            {
                missedLetters.Add(guess);
                hangman.IncrementIncorrectAttempts();

                if (hangman.IsGameOver())
                {
                    hangman.DisplayHangman();
                    Console.WriteLine($"Tu as épuisé tes essais. Le mot secret était {secretWord}.");
                    gameIsDone = true;
                }
            }
        }
    }

    static string GetRandomWord(string[] wordList)
    {
        Random random = new Random();
        int wordIndex = random.Next(0, wordList.Length);
        return wordList[wordIndex];
    }

    static void DisplayBoard(List<char> missedLetters, List<char> correctLetters, string secretWord)
    {
        Console.Write("Lettres déjà proposées : ");
        foreach (char letter in missedLetters)
        {
            Console.Write(letter + " ");
        }
        Console.WriteLine();

        char[] displayWord = new char[secretWord.Length];
        for (int i = 0; i < secretWord.Length; i++)
        {
            if (correctLetters.Contains(secretWord[i]))
            {
                displayWord[i] = secretWord[i];
            }
            else
            {
                displayWord[i] = '_';
            }
        }

        Console.WriteLine("Mot à deviner : " + new string(displayWord));
    }

    static char GetGuess(List<char> missedLetters, List<char> correctLetters)
    {
        while (true)
        {
            Console.WriteLine("Proposer une lettre : ");
            string input = Console.ReadLine().ToLower();

            if (input.Length != 1)
            {
                Console.WriteLine("Proposer une SEULE LETTRE svp.");
            }
            else
            {
                char guess = input[0];

                if (correctLetters.Contains(guess) || missedLetters.Contains(guess))
                {
                    Console.WriteLine("Tu as déjà proposé cette lettre.");
                }
                else if (!char.IsLetter(guess))
                {
                    Console.WriteLine("Proposer une LETTRE svp.");
                }
                else
                {
                    return guess;
                }
            }
        }
    }

    static bool CheckWin(string secretWord, List<char> correctLetters)
    {
        foreach (char letter in secretWord)
        {
            if (!correctLetters.Contains(letter))
            {
                return false;
            }
        }

        return true;
    }
}
