﻿using System;

class Program
{
    static void Main(string[] args)
    {
        bool recommencer = true;

        while (recommencer)
        {
            Console.WriteLine("Cliquez sur une touche pour jouer au Jeu du + ou - Version 2 améliorée");
            Console.ReadKey();
            Console.Clear(); // Effacer la console avant de lancer le jeu

            Console.WriteLine("Jeu du + ou - Version 2 améliorée");

            int valeurATrouver = new Random().Next(0, 100);
            int nombreDeCoups = 0;

            Console.WriteLine("\nVeuillez saisir un nombre compris entre 0 et 100\n");

            while (true)
            {
                string saisie = Console.ReadLine();
                int valeurSaisie;

                if (!int.TryParse(saisie, out valeurSaisie))
                {
                    Console.WriteLine("\nLa valeur saisie est incorrecte, veuillez recommencer ...\n");
                    continue;
                }

                if (valeurSaisie < 0 || valeurSaisie >= 100)
                {
                    Console.WriteLine("\nVous devez saisir un nombre entre 0 et 100\n");
                    continue;
                }

                nombreDeCoups++;

                if (valeurSaisie == valeurATrouver)
                {
                    Console.WriteLine("Bien joué ! Vous avez trouvé le bon chiffre en " + nombreDeCoups + " coups\n");
                    break;
                }
                else
                {
                    if (valeurSaisie < valeurATrouver)
                        Console.WriteLine("\nTrop petit...");
                    else
                        Console.WriteLine("\nTrop grand...");
                }

                if (nombreDeCoups == 1)
                    Console.WriteLine("Vous avez effectué " + nombreDeCoups + " coup\n");
                else
                    Console.WriteLine("Vous avez effectué " + nombreDeCoups + " coups\n");
            }

            // Demander si l'utilisateur veut recommencer
            Console.WriteLine("\nVoulez-vous recommencer ? (Oui/Non)\n");
            string choix = Console.ReadLine();

            if (choix.ToLower() != "oui")
                recommencer = false;
            else
                Console.Clear(); // Effacer la console pour recommencer le jeu
        }

        Console.WriteLine("\nAppuyez sur une touche pour quitter...");
        Console.ReadKey();
    }
}
