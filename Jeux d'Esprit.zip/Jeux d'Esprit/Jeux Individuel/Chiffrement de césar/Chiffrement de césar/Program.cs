﻿using System;

class Program
{
    static void Main()
    {
        // Afficher un message demandant à l'utilisateur de cliquer pour jouer
        Console.WriteLine("Cliquez sur une touche pour commencer à jouer.");
        Console.ReadKey(true);

        bool recommencer;
        do
        {
            // Effacer la console pour nettoyer l'écran avant de commencer le jeu
            Console.Clear();
            AfficherEnTete(); // Afficher l'en-tête du jeu

            // Demander à l'utilisateur s'il veut crypter, décrypter ou décrypter par force brute
            Console.WriteLine("\nMenu principal :");
            Console.WriteLine("1. Cryptage");
            Console.WriteLine("2. Décryptage");
            Console.WriteLine("3. Décryptage en force brute");
            Console.Write("Choisissez une option (1, 2 ou 3) : ");
            char choix = char.ToUpper(Console.ReadKey().KeyChar);
            Console.WriteLine();

            if (choix == '1')
            {
                // Demander à l'utilisateur d'entrer le choix de sa ROT
                int rot = DemanderROT();

                // Demander à l'utilisateur d'entrer le message à crypter
                Console.Write("Entrez le message à crypter : ");
                string message = Console.ReadLine();

                // Appeler la fonction de chiffrement de César avec la clé choisie
                string messageCrypte = ChiffrerCesar(message, rot);

                // Afficher le message crypté
                Console.WriteLine($"Message crypté : {messageCrypte}");
            }
            else if (choix == '2')
            {
                // Demander à l'utilisateur d'entrer le choix de sa ROT
                int rot = DemanderROT();

                // Demander à l'utilisateur d'entrer le message à décrypter
                Console.Write("Entrez le message à décrypter : ");
                string messageCrypte = Console.ReadLine();

                // Appeler la fonction de déchiffrement de César avec la clé choisie
                string messageDecrypte = DechiffrerCesar(messageCrypte, rot);

                // Afficher le message décrypté
                Console.WriteLine($"Message décrypté : {messageDecrypte}");
            }
            else if (choix == '3')
            {
                // Demander à l'utilisateur d'entrer le message à décrypter par force brute
                Console.Write("Entrez le message à décrypter par force brute : ");
                string messageCrypte = Console.ReadLine();

                // Effacer la console pour nettoyer l'écran avant d'afficher les résultats du décryptage par force brute
                Console.Clear();

                // Décrypter par force brute et afficher les résultats
                DecrypterParForceBrute(messageCrypte);
            }
            else
            {
                Console.WriteLine("Choix invalide. Veuillez choisir 1 pour crypter, 2 pour décrypter, ou 3 pour décrypter par force brute.");
            }

            // Demander à l'utilisateur s'il veut recommencer
            recommencer = Recommencer();

        } while (recommencer);

        Console.WriteLine("Programme terminé. Appuyez sur une touche pour fermer la fenêtre.");
        Console.ReadKey();
    }

    // Méthode pour afficher l'en-tête du jeu
    static void AfficherEnTete()
    {
        Console.WriteLine("Bienvenue dans le jeu de chiffrement de César !\n");
        Console.WriteLine("Le chiffrement de César est une méthode de cryptage très simple où chaque lettre du message est décalée d'un certain nombre de positions dans l'alphabet.");
        Console.WriteLine("Vous allez maintenant pouvoir jouer en choisissant parmi les options suivantes :");
    }

    // Fonction pour chiffrer le message avec le chiffrement de César
    static string ChiffrerCesar(string message, int cle)
    {
        // Initialiser une chaîne vide pour le message crypté
        string messageCrypte = "";

        // Parcourir chaque caractère dans le message
        foreach (char caractere in message)
        {
            // Vérifier si le caractère est une lettre
            if (char.IsLetter(caractere))
            {
                // Décaler le caractère en fonction de la clé
                char caractereCrypte = (char)(caractere + cle);

                // Gérer le cas où le décalage dépasse la fin de l'alphabet
                if ((char.IsUpper(caractere) && caractereCrypte > 'Z') || (char.IsLower(caractere) && caractereCrypte > 'z'))
                {
                    caractereCrypte = (char)(caractereCrypte - 26);
                }

                // Ajouter le caractère crypté à la chaîne de résultat
                messageCrypte += caractereCrypte;
            }
            else
            {
                // Si le caractère n'est pas une lettre, ajouter tel quel à la chaîne de résultat
                messageCrypte += caractere;
            }
        }

        // Renvoyer le message crypté
        return messageCrypte;
    }

    // Fonction pour déchiffrer le message avec le chiffrement de César
    static string DechiffrerCesar(string messageCrypte, int cle)
    {
        // Utiliser la fonction ChiffrerCesar avec une clé négative pour le déchiffrement
        return ChiffrerCesar(messageCrypte, 26 - (cle % 26));
    }

    // Fonction pour décrypter par force brute
    static void DecrypterParForceBrute(string messageCrypte)
    {
        Console.WriteLine("Décryptage par force brute en cours...");

        // Parcourir toutes les clés possibles de 1 à 26
        for (int cle = 1; cle <= 26; cle++)
        {
            // Appeler la fonction de déchiffrement de César avec la clé choisie
            string messageDecrypte = DechiffrerCesar(messageCrypte, cle);

            // Afficher le message décrypté avec la clé correspondante
            Console.WriteLine($"ROT {cle} : {messageDecrypte}");
        }

        Console.WriteLine("Décryptage par force brute terminé.");
    }

    // Fonction pour demander à l'utilisateur de choisir une clé
    static int DemanderROT()
    {
        int rot;
        do
        {
            Console.Write("Entrez la valeur de votre ROT (entre 1 et 26) : ");
        } while (!int.TryParse(Console.ReadLine(), out rot) || rot < 1 || rot > 26);

        return rot;
    }

    // Fonction pour demander à l'utilisateur s'il veut recommencer
    static bool Recommencer()
    {
        Console.Write("Voulez-vous recommencer ? (Oui/Non) : ");
        string reponse = Console.ReadLine().Trim().ToUpper();
        return reponse == "OUI" || reponse == "O";
    }
}
