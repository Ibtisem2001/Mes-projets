<?php
// Activer l'affichage des erreurs pour le debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inclure la connexion à la base de données
include('db.php');

// Vérifier la connexion
if (!$db) {
    die("❌ Erreur de connexion à la base de données.");
}

// Récupérer le nombre total d'inscriptions
$total_courses = $db->query("SELECT COUNT(*) AS total FROM event_registrations")->fetch_assoc();

// Récupérer le nombre d'inscriptions par épreuve
$result = $db->query("SELECT event_id, COUNT(*) AS count FROM event_registrations GROUP BY event_id");
$categories = [];
while ($row = $result->fetch_assoc()) {
    $categories[] = $row;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistiques des Courses</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<?php include('header.php'); ?>

    <h1>Statistiques des Courses</h1>

    <h2>Nombre total d'inscriptions</h2>
    <p><?= $total_courses['total']; ?> inscriptions enregistrées</p>

    <h2>Répartition des inscriptions par épreuve</h2>
    <canvas id="epreuvesChart"></canvas>

    <script>
        const epreuvesData = {
            labels: [<?php foreach ($categories as $cat) echo "'Épreuve " . $cat['event_id'] . "', "; ?>],
            datasets: [{
                label: 'Participants',
                data: [<?php foreach ($categories as $cat) echo $cat['count'] . ", "; ?>],
                backgroundColor: 'rgba(153, 102, 255, 0.2)',
                borderColor: 'rgba(153, 102, 255, 1)',
                borderWidth: 1
            }]
        };

        new Chart(document.getElementById('epreuvesChart'), {
            type: 'bar',
            data: epreuvesData,
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false },
                    title: { display: true, text: 'Répartition des inscriptions par épreuve' }
                }
            }
        });
    </script>
</body>
</html>
