<?php
// Inclure la connexion à la base de données
include 'db.php';

// Vérifier que les données sont soumises
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $db->real_escape_string($_POST['name']);
    $description = $db->real_escape_string($_POST['description']);

    // Insérer dans la table courses
    $sql = "INSERT INTO courses (name, description) VALUES ('$name', '$description')";
    if ($db->query($sql)) {
        echo "<script>alert('La course a été ajoutée avec succès.');</script>";
    } else {
        echo "<script>alert('Erreur : " . $db->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Course</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        /* Style global */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: #fff;
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            padding: 30px;
            max-width: 400px;
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.2);
            text-align: center;
            color: #333;
        }

        .form-container h1 {
            margin-bottom: 20px;
            font-size: 2rem;
            color: #333;
        }

        .form-container label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            text-align: left;
        }

        .form-container input, 
        .form-container textarea, 
        .form-container button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 1rem;
            font-family: 'Poppins', sans-serif;
        }

        .form-container textarea {
            resize: none;
            height: 100px;
        }

        .form-container button {
            background: #6a11cb;
            color: #fff;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .form-container button:hover {
            background: #2575fc;
        }

        .form-container a {
            color: #6a11cb;
            text-decoration: none;
            font-weight: 600;
            display: inline-block;
            margin-top: 10px;
            transition: all 0.3s ease;
        }

        .form-container a:hover {
            color: #2575fc;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Ajouter une Course</h1>
        <form action="ajouter_course.php" method="POST">
            <label for="name">Nom de la course :</label>
            <input type="text" id="name" name="name" placeholder="Entrez le nom de la course" required>
            
            <label for="description">Description :</label>
            <textarea id="description" name="description" placeholder="Entrez une description" required></textarea>
            
            <button type="submit">Ajouter la Course</button>
        </form>
        <a href="index1.php">Retour à l'accueil</a>
    </div>
</body>
</html>
