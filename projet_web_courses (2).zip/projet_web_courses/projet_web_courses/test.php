<?php
echo "PHP fonctionne !";
?>
