<?php
session_start();
require 'db.php'; // Connexion à la base de données

// Vérifier la connexion
if (!$db) {
    die("Erreur de connexion à la base de données.");
}

// 📌 Récupérer les événements depuis la table `events`
$query = "SELECT name, date, location FROM events ORDER BY date ASC";
$result = $db->query($query);

// 📌 Stocker les événements sous forme de tableau PHP
$events = [];
while ($row = $result->fetch_assoc()) {
    $events[] = [
        'title' => $row['name'],
        'start' => $row['date'],
        'location' => $row['location']
    ];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendrier</title>

    <!-- 📌 Lien CSS pour FullCalendar -->
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }

        h1 {
            background-color: #3498db;
            color: white;
            padding: 15px;
            margin: 0;
        }

        #calendar {
            max-width: 800px;
            margin: 20px auto;
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>

    <!-- 📌 Inclusion du menu de navigation -->
    <?php include('header.php'); ?>

    <!-- 📌 Titre -->
    <h1>📅 Calendrier des Événements</h1>

    <!-- 📌 Affichage du calendrier -->
    <div id="calendar"></div>

    <!-- 📌 Script FullCalendar -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var calendarEl = document.getElementById('calendar');

            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth', 
                locale: 'fr', 
                events: <?= json_encode($events); ?>,
                eventClick: function (info) {
                    alert("📍 " + info.event.title + "\n📍 Lieu : " + info.event.extendedProps.location);
                }
            });

            calendar.render();
        });
    </script>

</body>
</html>
