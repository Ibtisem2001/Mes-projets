<?php
session_start(); // Démarre la session PHP
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WebCourses</title>
    <link rel="stylesheet" href="style_global.css">
    <link rel="stylesheet" href="style_home.css">
    <link rel="stylesheet" href="style.css">
    </head>
<body>
<body>
<header class="header">
    
    <div class="container">
        <span class="site-title">WebCourses</span>
    </div>
    <nav class="nav">
        <ul class="nav-links">
            <li><a href="index1.php">Accueil</a></li>
            <li><a href="qui_sommes_nous.php">Qui sommes-nous ?</a></li>
            <li><a href="inscription_evenement.php">Événements</a></li>
            <li><a href="statistique_course.php">statistiques</a></li>
            <li><a href="activites.php">Activités</a></li>
            <li><a href="inscription_coureur.php">inscription coureur</a></li>
            <li><a href="info_club.php">Informations Club</a></li>
            <li><a href="calendar.php">calendrier</a></li>
            <li><a href="formulaire.php">Formulaire</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="deconnexion.php" class="btn-deconnexion">Déconnexion</a></li>
        </ul>
    </nav>
</header>
            </ul>
        </nav>
    </header>
</body>
</html>