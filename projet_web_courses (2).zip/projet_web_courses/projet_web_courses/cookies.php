<div id="cookie-banner" class="cookie-banner">
    <p>
        Nous utilisons des cookies pour améliorer votre expérience sur notre site. En poursuivant votre navigation, vous acceptez notre utilisation des cookies. 
        <a href="page_cookies.php" target="_blank">En savoir plus</a>.
    </p>
    <button id="accept-cookies" class="btn-accept">Accepter</button>
</div>
