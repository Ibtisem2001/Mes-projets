<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contactez-vous</title>
    <link href="contact.css" rel="stylesheet"> <!-- Ajoute ton fichier CSS -->
</head>
<body>
    <div class="contact-container">
        <h1>Contactez-vous</h1>
        <form action="process_contact.php" method="POST">
            <label for="name">Votre nom :</label>
            <input type="text" id="name" name="name" placeholder="Entrez votre nom" required>

            <label for="email">Votre email :</label>
            <input type="email" id="email" name="email" placeholder="Entrez votre email" required>

            <label for="message">Votre message :</label>
            <textarea id="message" name="message" placeholder="Écrivez votre message ici..." required></textarea>

            <button type="submit">Envoyer</button>
        </form>
    </div>
</body>
</html>
