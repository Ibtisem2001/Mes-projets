<?php session_start(); ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Qui sommes-nous ? - WebCourses</title>
    
    <!-- Liens vers les styles -->
    <link rel="stylesheet" href="style_global.css?v=105">
    <link rel="stylesheet" href="style_home.css?v=105">
    <link rel="stylesheet" href="style.css?v=105">
    <link rel="stylesheet" href="style/qui_sommes_nous.css?v=105">
</head>
<body>
    <?php include('header.php'); ?>
    
    <div class="container">
        <h1 class="page-title">Le corps avec le vélo peut tout faire : Cycle de la vie !</h1>
        
        <section class="about-section">
            <h2>Notre Histoire</h2>
            <p>Association de la loi 1901 créée en 1960, par deux frères passionnés de courses de vélos.</p>
            <p>Et c'est là que tout a commencé... Enchaînement d'actions.</p>
            <p>Aujourd'hui, notre association compte plus d'un million de membres, dont dix mille professionnels répartis dans diverses catégories comme la course à pied, le vélo, la natation, et parmi lesquels nous retrouvons des champions connus !</p>
            <img src="image/photo_cycliste.jpg" alt="Photo de l'équipe" class="about-image">
        </section>
        
        <section class="location-section">
            <h2>Plan d'accès</h2>
            <img src="image/plan_d_acces.jpg" alt="Plan d'accès" class="location-map">
            <p><strong>Adresse :</strong> 11 Av. du Tremblay, 75012 Paris</p>
        </section>
        
        <section class="contact-section">
            <h2>Contacter les fondateurs</h2>
            <p><strong>Email :</strong> <a href="mailto:jim@rock.com">jim@rock.com</a></p>
            <p><strong>Téléphone :</strong> <a href="tel:+33615552368">06 06 06 32 28</a></p>
        </section>
        
        <section class="legal-section">
            <h2>Mentions légales</h2>
            <p>(Paragraphe vide pour l'instant)</p>
            <p>Voir notre politique de confidentialité + charte cookies en cliquant <a href="#">ici</a>.</p>
        </section>
        
        <section class="newsletter-section">
            <h2>Restez informé !</h2>
            <p>Vous connaissez à présent l'équipe et le projet ! Cela a éveillé votre curiosité ? Restez informé en souscrivant à la newsletter et recevez les dernières actualités.</p>
            <button class="subscribe-btn">Cliquez-ici pour vous abonner !</button>
        </section>
    </div>
    
    <?php include('footer.php'); ?>
</body>
</html>