<?php
echo "Test du fichier index.php";
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WebCourses - Site des coureurs</title>
    <link rel="stylesheet" href="style_global.css?v=104">
    <link rel="stylesheet" href="style_home.css?v=104">
    <link rel="stylesheet" href="style.css?v=104">
</head>
<body>
<header class="header">
    
    <div class="container">
        <span class="site-title">WebCourses</span>
    </div>
    <nav class="nav">
        <ul class="nav-links">
            <li><a href="#home">Accueil</a></li>
            <li><a href="qui_sommes_nous.php">Qui sommes-nous ?</a></li>
            <li><a href="inscription_evenement.php">Événements</a></li>
            <li><a href="statistique_course.php">statistiques</a></li>
            <li><a href="inscription_coureur.php">inscription coureur</a></li>
            <li><a href="activites.php">Activités</a></li>
            <li><a href="info_club.php">Informations Club</a></li>
            <li><a href="formulaire.php">Formulaire</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="deconnexion.php" class="btn-deconnexion">Déconnexion</a></li>
        </ul>
    </nav>
</header>

<section id="home" class="hero">
    <div class="hero-content">
        <h1>Bienvenue sur <span class="highlight">WebCourses</span></h1>
        <p>Transformez votre passion pour la course en une expérience incroyable. Connectez-vous, organisez et excellez avec nous !</p>
        <a href="#features" class="btn-primary">Découvrez nos fonctionnalités</a>
    </div>
</section>

<section id="features" class="features-container">
    <h2>Nos Fonctionnalités</h2>
    <div class="features-grid">
        <div class="feature-card">
            <h3>Suivi des courses</h3>
            <p>Analysez vos performances et progressez avec des outils d'analyse avancés.</p>
            <a href="performances.php" class="btn btn-primary">Voir les performances</a>
        </div>
        <div class="feature-card">
            <h3>Communauté</h3>
            <p>Partagez vos expériences avec d'autres coureurs passionnés.</p>
            <a href="communaute.php" class="btn btn-primary">Découvrir la Communauté</a>
        </div>
        <div class="feature-card">
            <h3>Calendrier</h3>
            <p>Planifiez vos événements sportifs et restez organisé.</p>
            <a href="calendar.php" class="btn btn-primary">Voir le Calendrier</a>
        </div>
        <div class="feature-card">
            <h3>Ajouter</h3>
            <p>Organiser vos événements sportifs et restez organisé.</p>
            <a href="ajouter_course.php" class="btn btn-primary">Ajouter la course</a>
        </div>
    </div>
</section>

<section id="events" class="events">
    <h2>Événements à venir</h2>
    <div class="event-list">
        <div class="event">
            <div class="event-icon">🏃</div>
            <div>
                <h3>Marathon de Paris</h3>
                <p>Avril 2024 - Inscrivez-vous dès maintenant.</p>
            </div>
        </div>
        <div class="event">
            <div class="event-icon">🌙</div>
            <div>
                <h3>Course Nocturne</h3>
                <p>Juillet 2024 - Courez sous les étoiles pour une expérience unique.</p>
            </div>
        </div>
    </div>
</section>

<!-- FOOTER -->
<!-- Bannière de cookies -->


<div class="cookie-banner" id="cookie-banner">
    <p>
    
     Ce site web stocke les cookies sur votre ordinateur. Ces cookies sont utilisés pour collecter des informations sur la manière dont vous interagissez avec notre site web et nous permettent de nous souvenir de vous. Nous utilisons ces informations afin d'améliorer et de personnaliser votre expérience de navigation, ainsi que pour les données et les indicateurs concernant nos visiteurs à la fois sur ce site web et sur d'autres supports. Pour en savoir plus sur les cookies que nous utilisons, consultez notre Politique de confidentialité.
    Si vous refusez l'utilisation des cookies, vos informations ne seront pas suivies lors de votre visite sur ce site. Un seul cookie sera utilisé dans votre navigateur afin de se souvenir de ne pas suivre vos préférences.
    <a href="/politiques-rgpd"> En savoir plus </a>
    
    <img src="./image/coo.jpg" title="Image Vélo" alt="image velo" id="image1"/>  
   
</p> 
<button id="accept-cookies">Accepter les cookies</button>
<button id="refuser-cookies">Refuser les cookies</button>
<button id="refuser-cookies">gerer les cookies</button>
    </div>
</div>



<script src="script.js">
    
</script>

