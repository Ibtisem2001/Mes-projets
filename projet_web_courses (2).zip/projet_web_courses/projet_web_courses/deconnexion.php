<?php
include('connexion_db.php'); // Inclure la connexion à la base de données
session_start();

// Initialisation du message d'erreur
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer et valider les champs
    $email = htmlspecialchars(trim($_POST['email']));
    $mot_de_passe = trim($_POST['mot_de_passe']);

    // Vérification des champs vides
    if (empty($email) || empty($mot_de_passe)) {
        $message = "Veuillez remplir tous les champs.";
    } else {
        // Préparation de la requête SQL
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // Vérification si un compte existe
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            // Vérification du mot de passe
            if (password_verify($mot_de_passe, $user['mot_de_passe'])) {
                // Stockage des informations en session
                $_SESSION['is_logged_in'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['nom'];

                // Redirection vers la page d'accueil
                header('Location: index1.php');
                exit();
            } else {
                $message = "Mot de passe incorrect.";
            }
        } else {
            $message = "Aucun compte trouvé avec cet email.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <style>
        /* Général */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f7f7f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Conteneur principal */
        .login-container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 100%;
            max-width: 400px;
        }

        .login-logo {
            width: 80px;
            margin-bottom: 20px;
        }

        /* Titre du formulaire */
        h1 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }

        /* Champs de formulaire */
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="email"]:focus, input[type="password"]:focus {
            border-color: #E8A0BC;
            outline: none;
        }

        /* Message d'erreur */
        .error-message {
            color: red;
            font-size: 14px;
            margin-bottom: 15px;
        }

        /* Options supplémentaires */
        .form-options {
            margin-bottom: 15px;
            text-align: left;
        }

        .form-options label {
            font-size: 14px;
        }

        /* Bouton */
        .btn-primary {
            width: 100%;
            padding: 12px;
            background-color: #E8A0BC;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #d17a9c;
        }

        /* Liens supplémentaires */
        .form-links {
            margin-top: 15px;
            font-size: 14px;
        }

        .form-links a {
            color: #333;
            text-decoration: none;
        }

        .form-links a:hover {
            text-decoration: underline;
        }

        /* Bouton Inscription */
        .btn-inscription {
            width: 100%;
            padding: 12px;
            background-color: #4CAF50;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        .btn-inscription:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <!-- Logo -->
        <img src="image/r.jpg" alt="Logo" class="login-logo">

        <!-- Formulaire de connexion -->
        <form method="POST" action="connexion.php" class="login-form">
            <h1>Connexion</h1>

            <!-- Message d'erreur -->
            <?php if (!empty($message)) : ?>
                <p class="error-message"><?php echo $message; ?></p>
            <?php endif; ?>

            <!-- Champ Email -->
            <div class="form-group">
                <label for="email">Email ou Identifiant</label>
                <input type="email" id="email" name="email" placeholder="Entrez votre email" required>
            </div>

            <!-- Champ Mot de passe -->
            <div class="form-group">
                <label for="mot_de_passe">Mot de passe</label>
                <input type="password" id="mot_de_passe" name="mot_de_passe" placeholder="Entrez votre mot de passe" required>
            </div>

            <!-- Options supplémentaires -->
            <div class="form-options">
                <label>
                    <input type="checkbox" name="remember"> Se souvenir de moi
                </label>
            </div>

            <!-- Bouton Se connecter -->
            <button type="submit" class="btn-primary">Se connecter</button>

            <!-- Liens supplémentaires -->
            <div class="form-links">
                <a href="forgot_password.php">Mot de passe oublié ?</a>
            </div>
        </form>

        <!-- Bouton Inscription -->
        <form action="inscription.php" method="POST">
            <button type="submit" class="btn-inscription">Inscription</button>
        </form>
    </div>
</body>
</html>
