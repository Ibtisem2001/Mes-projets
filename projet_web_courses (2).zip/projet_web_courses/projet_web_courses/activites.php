<?php
// Active l'affichage des erreurs (utile pour voir si on fait une erreur)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// On inclut la connexion à la base de données
include('db.php');

// Vérifier si la connexion fonctionne
if (!$db) {
    die("❌ Erreur de connexion à la base de données.");
}

// Récupérer toutes les activités de la base de données
$result = $db->query("SELECT * FROM activites");

// On stocke les activités dans une liste vide
$activites = [];

// Tant qu'on a des activités, on les ajoute à la liste
while ($row = $result->fetch_assoc()) {
    $activites[] = $row;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Liste des Activités</title>
    
    <style>
        /* Style général de la page */
body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
    text-align: center;
    margin: 0;
    padding: 0;
}

/* Style du tableau */
table {
    width: 80%;
    margin: 40px auto;
    border-collapse: collapse;
    background: white;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
    border-radius: 10px;
    overflow: hidden;
}

th, td {
    padding: 15px;
    border: 1px solid #bbb;
    text-align: center;
}

th {
    background-color: #007BFF;
    color: white;
    font-weight: bold;
    text-transform: uppercase;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

    </style>
</head>
<body>
<?php include('header.php'); ?> <!-- On ajoute le menu du site -->

    <h1>Liste des Activités</h1>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Catégorie</th>
                <th>Description</th>
                <th>Date Début</th>
                <th>Date Fin</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($activites as $activite): ?>
                <tr>
                    <td><?= htmlspecialchars($activite['id']); ?></td>
                    <td><?= htmlspecialchars($activite['categorie']); ?></td>
                    <td><?= htmlspecialchars($activite['description']); ?></td>
                    <td><?= htmlspecialchars($activite['date_debut']); ?></td>
                    <td><?= htmlspecialchars($activite['date_fin']); ?></td>
                </tr>
                
            <?php endforeach; ?>
        </tbody>
    </table> <a href="index.php" class="btn-retour">← Retour à l'accueil</a>

</body>
</html>
