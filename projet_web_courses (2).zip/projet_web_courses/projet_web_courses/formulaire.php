<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire - Validation Regex</title>
    <link rel="stylesheet" href="formulaire.css">
    <link rel="stylesheet" href="contact.php">
    <link rel="stylesheet" href="index1.php">
</head>
<body>
    <header>
        <nav class="nav">
            <div class="logo">
                <a href="index.php#home"><img src="./image/r.jpg" alt="Logo WebCourses"></a>
            </div>
            <ul class="nav-links">
                <li><a href="index1.php#home">Accueil</a></li>
                <li><a href="index1.php#features">Fonctionnalités</a></li>
                <li><a href="index1.php#events">Événements</a></li>
                <li><a href="formulaire.php" class="active">Formulaire</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="deconnexion.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="form-container">
            <h1>Inscription à une épreuve</h1>
            <form method="post" action="">
                <label for="telephone">Votre téléphone :</label>
                <input type="text" id="telephone" name="telephone" placeholder="Ex : 06 12 34 56 78" required>

                <label for="mail">Votre email :</label>
                <input type="email" id="mail" name="mail" placeholder="Ex : exemple@domaine.com" required>

                <input type="submit" value="Envoyer">
            </form>

            <?php
            // Traitement du formulaire
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                // Récupérer les valeurs des champs
                $telephone = $_POST['telephone'] ?? '';
                $mail = $_POST['mail'] ?? '';

                // Regex pour le numéro de téléphone français
                $regex_telephone = "#^0[1-9]([-. ]?[0-9]{2}){4}$#";

                // Regex pour l'adresse email
                $regex_mail = "#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#";

                // Validation du numéro de téléphone
                if (preg_match($regex_telephone, $telephone)) {
                    echo "<p style='color: green;'>Numéro de téléphone valide.</p>";
                } else {
                    echo "<p style='color: red;'>Numéro de téléphone invalide. Format attendu : 06 12 34 56 78</p>";
                }

                // Validation de l'adresse email
                if (preg_match($regex_mail, $mail)) {
                    echo "<p style='color: green;'>Adresse email valide.</p>";
                } else {
                    echo "<p style='color: red;'>Adresse email invalide. Format attendu : exemple@domaine.com</p>";
                }
            }
            ?>
        </div>
    </main>

    <footer>
        <p>&copy; WebCourses - <a href="mentions_legalesv2.pdf">Mentions légales</a> | 
            <a href="politique_de_confidentialite.pdf">Politique de confidentialité</a> | 
            <a href="gestion_des_cookies.pdf">Gestion des cookies</a> | 
            <a href="droitimage.pdf">Droit à l'image</a>
        </p>
    </footer>
</body>
</html>

