<?php
session_start();
require 'db.php'; // Connexion à la base de données
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Communauté - WebCourses</title>
    <link rel="stylesheet" href="style_global.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f9f9;
        }

        header {
            background-color: #deb4d2;
            color: white;
            text-align: center;
            padding: 20px;
        }

        h1 {
            font-size: 2.5rem;
        }

        table {
            margin: 20px auto;
            width: 90%;
            border-collapse: collapse;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        table thead {
            background-color: #deb4d2;
            color: white;
        }

        .btn-back {
            margin: 20px auto;
            display: block;
            width: 200px;
            text-align: center;
            padding: 10px;
            background-color: #deb4d2;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .btn-back:hover {
            background-color: #deb4d2;
        }
    </style>
</head>
<body>
    <header>
        <h1>Communauté des Coureurs</h1>
    </header>
    <main>
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Rôle</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT name, role, description FROM community ORDER BY name ASC";
                $result = $db->query($query);

                while ($member = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($member['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($member['role']) . "</td>";
                    echo "<td>" . htmlspecialchars($member['description']) . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <a href="index1.php" class="btn-back">Retour à l'accueil</a>
    </main>
</body>
</html>
