<?php
$host = 'localhost';
$username = 'root'; // Nom d'utilisateur MySQL (par défaut)
$password = 'root'; // Mot de passe (laisser vide si non configuré)
$dbname = 'appliwebcourses'; // Nom de la base de données

// Connexion à la base de données
$conn = new mysqli($host, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}
?>
