<?php
// Configuration de la connexion
$host = 'localhost'; // Hôte (serveur MySQL local)
$username = 'root'; // Nom d'utilisateur MySQL (par défaut : root)
$password = ''; // Mot de passe MySQL (vide si non configuré)
$dbname = 'appliwebcourses'; // Nom de la base de données

// Créer la connexion à MySQL
$conn = new mysqli($host, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
} else {
    echo "Connexion à la base de données réussie !<br>";
}

// Tester une requête pour vérifier la table `activites`
$sql = "SELECT * FROM activites";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "Les activités suivantes sont disponibles :<br><br>";
    while ($row = $result->fetch_assoc()) {
        echo "Catégorie : " . htmlspecialchars($row['categorie']) . "<br>";
        echo "Description : " . htmlspecialchars($row['description']) . "<br>";
        echo "Date de début : " . htmlspecialchars($row['date_debut']) . "<br>";
        echo "Date de fin : " . htmlspecialchars($row['date_fin']) . "<br><br>";
    }
} else {
    echo "Aucune activité trouvée dans la table `activites`.";
}

// Fermer la connexion
$conn->close();
?>
