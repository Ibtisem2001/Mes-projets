<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require 'db.php'; // Connexion à la base de données via MySQLi

if (!isset($db)) {
    die("Erreur : Connexion à la base de données non établie.");
}

// Vérification si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id']; 
    $licence = htmlspecialchars($_POST['licence']);
    $event_id = intval($_POST['evenement']); 
    $registration_date = date("Y-m-d H:i:s");

    // Vérifier si l'utilisateur est déjà inscrit
    $stmt = $db->prepare("SELECT * FROM event_registrations WHERE user_id = ? AND event_id = ?");
    $stmt->bind_param("ii", $user_id, $event_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        die("⚠️ Vous êtes déjà inscrit à cet événement.");
    }

    // Insérer l'inscription
    $stmt = $db->prepare("INSERT INTO event_registrations (user_id, event_id, registration_date) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $user_id, $event_id, $registration_date);

    if ($stmt->execute()) {
        echo "✅ Inscription réussie !";
        header("Location: /projet_web_courses/confirmation.php");

        exit();
    } else {
        echo "❌ Erreur lors de l'inscription.";
    }
}
