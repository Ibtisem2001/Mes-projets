<?php
// Activer les erreurs pour le débogage
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Démarrer la session
session_start();

// Connexion à la base de données
try {
    $conn = new PDO("mysql:host=localhost;dbname=appliwebcourses", "root", "root");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Générer les nombres pour le CAPTCHA si non générés ou après une soumission invalide
if (!isset($_SESSION['captcha_number1'], $_SESSION['captcha_number2'])) {
    $_SESSION['captcha_number1'] = rand(1, 10);
    $_SESSION['captcha_number2'] = rand(1, 10);
}

// Calculer le résultat attendu du CAPTCHA
$expected_captcha_result = $_SESSION['captcha_number1'] + $_SESSION['captcha_number2'];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données du formulaire
    $email = isset($_POST['email']) ? htmlspecialchars(trim($_POST['email'])) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $captcha = isset($_POST['captcha']) ? (int)trim($_POST['captcha']) : null;

    // Vérifications
    if (empty($email) || empty($password) || empty($captcha)) {
        $error = "Tous les champs sont requis.";
    } elseif ($captcha !== $expected_captcha_result) {
        $error = "CAPTCHA incorrect. Réessayez.";
        // Regénérer le CAPTCHA pour une nouvelle tentative
        $_SESSION['captcha_number1'] = rand(1, 10);
        $_SESSION['captcha_number2'] = rand(1, 10);
    } else {
        // Préparer la requête SQL pour vérifier l'utilisateur
        $stmt = $conn->prepare("SELECT id, mot_de_passe FROM users WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['mot_de_passe'])) {
            // Authentification réussie
            $_SESSION['user_id'] = $user['id'];
            unset($_SESSION['captcha_number1'], $_SESSION['captcha_number2']); // Nettoyer les données CAPTCHA
            header("Location: index1.php");
            exit;
        } else {
            $error = "Email ou mot de passe incorrect.";
            // Regénérer le CAPTCHA pour une nouvelle tentative
            $_SESSION['captcha_number1'] = rand(1, 10);
            $_SESSION['captcha_number2'] = rand(1, 10);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <style>
        /* === Styling général === */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            background: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }

        h1 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            font-size: 1rem;
            color: #555;
            display: block;
            text-align: left;
            margin-bottom: 8px;
        }

        input[type="email"],
        input[type="password"],
        input[type="text"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1rem;
        }

        input:focus {
            border-color: #deb4d2;
            outline: none;
        }

        .btn-primary {
            background-color: #deb4d2;
            color: white;
            padding: 12px;
            width: 100%;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .btn-primary:hover {
            background-color: #c48dbd;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        .captcha-container {
            background: #f3f4f6;
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 15px;
            text-align: center;
            font-size: 1.2rem;
            font-family: 'Poppins', sans-serif;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .error-message {
            color: red;
            margin-top: 10px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Connexion</h1>
        <form method="POST" action="">
            <label for="email">Email ou Identifiant</label>
            <input type="email" id="email" name="email" placeholder="Exemple : user@mail.com" required>
            
            <label for="password">Mot de passe</label>
            <input type="password" id="password" name="password" placeholder="••••••••" required>
            
            <label for="captcha">CAPTCHA</label>
            <div class="captcha-container">
                <?php echo $_SESSION['captcha_number1']; ?> + <?php echo $_SESSION['captcha_number2']; ?>
            </div>
            <input type="text" id="captcha" name="captcha" placeholder="Réponse" required>
            
            <button type="submit" class="btn-primary">Se connecter</button>
        </form>
        <?php if (!empty($error)): ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
