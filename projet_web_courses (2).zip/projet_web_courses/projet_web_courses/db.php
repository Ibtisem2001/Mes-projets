<?php
// Informations de connexion à la base de données
$host = 'localhost';
$dbname = 'appliwebcourses'; // Assurez-vous que le nom est correct
$username = 'root';
$password = 'root'; // Pour MAMP, le mot de passe est souvent "root", 

// Connexion à la base de données
try {
    // Créer une connexion MySQLi
    $db = new mysqli($host, $username, $password, $dbname);

    // Vérifier les erreurs de connexion
    if ($db->connect_error) {
        die("Erreur de connexion à la base de données : " . $db->connect_error);
    }
} catch (Exception $e) {
    // Attraper une exception en cas de problème
    die("Erreur : " . $e->getMessage());
}
?>
