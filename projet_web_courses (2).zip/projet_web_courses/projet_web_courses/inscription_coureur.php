<?php
include 'db.php'; // Connexion à la base MySQLi

$message = "";

// Vérifier si le formulaire a bien été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1️⃣ Récupérer et nettoyer les données du formulaire
    $nom = isset($_POST['nom']) ? trim($_POST['nom']) : '';
    $prenom = isset($_POST['prenom']) ? trim($_POST['prenom']) : '';

    // Vérifier que les champs ne sont pas vides
    if (empty($nom) || empty($prenom)) {
        $message = "❌ Erreur : Tous les champs doivent être remplis !";
    } else {
        // 2️⃣ Vérifier si le coureur existe déjà dans la base
        $sql = "SELECT COUNT(*) FROM adherents WHERE adh_nom = ? AND adh_prenom = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("ss", $nom, $prenom);
        $stmt->execute();
        $stmt->bind_result($exist);
        $stmt->fetch();
        $stmt->close();

        // 3️⃣ Si le coureur existe déjà, afficher une erreur
        if ($exist > 0) {
            $message = "❌ Erreur : Ce coureur est déjà inscrit !";
        } 
        
        else {
            // 4️⃣ Insérer le coureur dans la base
            $sql = "INSERT INTO adherents (adh_nom, adh_prenom) VALUES (?, ?)";
            $stmt = $db->prepare($sql);
            $stmt->bind_param("ss", $nom, $prenom);

            if ($stmt->execute()) {
                $message = "✅ Inscription réussie !";
            } else {
                $message = "❌ Erreur lors de l'inscription.";
            }
            $stmt->close();
        }
    }
}
$db->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription Coureur</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        h1 {
            color: #333;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            gap: 15px;
            max-width: 400px;
            width: 100%;
        }
        input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        button {
            padding: 10px;
            background-color: #E8A0BC;
            border: none;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            font-size: 1rem;
            cursor: pointer;
        }
        button:hover {
            background-color: #d18aa4;
        }
        .message {
            color: red;
            font-size: 1rem;
            margin-bottom: 10px;
        }
        .message.success {
            color: green;
        }
    </style>
</head>
<body>
<?php include('header.php'); ?>
    <h1>Inscription Coureur</h1>
    <?php if (!empty($message)): ?>
        <p class="message <?php echo strpos($message, 'réussie') !== false ? 'success' : ''; ?>">
            <?php echo htmlspecialchars($message); ?>
        </p>
    <?php endif; ?>
    
    <form method="POST" action="">
        <label>Nom :</label>
        <input type="text" name="nom" required><br><br>
        
        <label>Prénom :</label>
        <input type="text" name="prenom" required><br><br>
        
        <button type="submit">S'inscrire</button>
    </form>
</body>
</html>
