<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation d'Inscription</title>
    <link rel="stylesheet" href="style_global.css">
</head>
<body>
    <?php include('header.php'); ?>

    <div class="container">
        <h1>✅ Inscription réussie !</h1>
        <p>Votre inscription à l'événement a bien été enregistrée.</p>
        <a href="index1.php" class="btn">Retour à l'accueil</a>
    </div>

    <footer>
        <p>&copy; 2025 WebCourses - <a href="mentions_legales.pdf">Mentions légales</a> - <a href="politique_de_confidentialite.pdf">Politique de confidentialité</a></p>
    </footer>
</body>
</html>
