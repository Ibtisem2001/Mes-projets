document.addEventListener("DOMContentLoaded", function() {
const cookieBanner = document.getElementById("cookie-banner")
const acceptButton = document.getElementById("accept-cookies")
function executeScripts(){
    console.log("les scripts sont déclenchés !")

}
if(localStorage.getItem('cookiesAccespted')=== 'true'){
    cookieBanner.style.display = "none";
    executeScripts();
}
acceptButton.addEventListener('click', function(){
    localStorage.setItem('cookiesAccepted', 'true');
    cookieBanner.style.display = "none";
    executeScripts();
})
})