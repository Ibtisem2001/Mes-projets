
<?php
// Démarrer la session
session_start();
try {
    $conn = new PDO("mysql:host=localhost;dbname=appliwebcourses;charset=utf8", "root", "root");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}
// Vérifier si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['user_id'])) {
        die("Erreur : Vous devez être connecté pour vous inscrire.");
    }

    $user_id = $_SESSION['user_id'];
    $event_id = $_POST['evenement'];
    $registration_date = date("Y-m-d H:i:s");

    // Insérer l'inscription
    $sql = "INSERT INTO event_registrations (user_id, event_id, registration_date) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt->execute([$user_id, $event_id, $registration_date])) {
        echo "Inscription réussie !";
        header("Location: confirmation.php");
        exit();
    } else {
        echo "Erreur lors de l'inscription.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription à un événement - WebCourses</title>
    <link rel="stylesheet" href="style_global.css">
    <link rel="stylesheet" href="inscription_evenement.css">
</head>

<body>
    <?php include('header.php'); ?>

    <div class="container">
        <h1>Inscription à un événement</h1>
        <p class="instruction">Veuillez remplir le formulaire ci-dessous pour réserver votre place :</p>

        <form action="traitement_inscription.php" method="POST" class="form-inscription">
            <label for="licence">Numéro de licence :</label>
            <input type="text" id="licence" name="licence" required>

            <label for="evenement">Choisir un événement :</label>
            <select id="evenement" name="evenement" required>
    <option value="">-- Sélectionnez un événement --</option>
    <?php
    require 'db.php'; // Connexion à la base
    $stmt = $conn->query("SELECT id, name FROM events ORDER BY date ASC");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<option value='" . $row['id'] . "'>" . htmlspecialchars($row['name']) . "</option>";
    }
    ?>
</select>


            <label for="categorie">Catégorie du coureur :</label>
            <select id="categorie" name="categorie" required>
                <option value="">-- Sélectionnez une catégorie --</option>
                <option value="junior">Junior</option>
                <option value="senior">Senior</option>
            </select>

            <button type="submit" class="btn-inscription">S'inscrire</button>
        </form>
    </div>

    <!-- FOOTER -->
    <footer>
        <p>&copy; 2025 WebCourses - <a href="mentions_legales.pdf">Mentions légales</a> - <a href="politique_de_confidentialite.pdf">Politique de confidentialité</a></p>
    </footer>

    <!-- Bannière de cookies -->
    <div class="cookie-banner" id="cookie-banner">
        <p>
            Ce site web stocke des cookies pour améliorer votre expérience. <a href="/politiques-rgpd"> En savoir plus </a>
        </p>
        <button id="accept-cookies">Accepter</button>
    </div>

    <script src="script.js"></script>
</body>
</html>
