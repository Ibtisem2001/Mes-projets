<?php
// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer et sécuriser les données
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));

    // Vérifier que tous les champs sont remplis
    if (!empty($name) && !empty($email) && !empty($message)) {
        // Vérifier que l'email est valide
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Exemple 1 : Enregistrer dans un fichier (optionnel)
            $logFile = 'messages.txt'; // Fichier où stocker les messages
            $logMessage = "Nom: $name\nEmail: $email\nMessage: $message\n---\n";
            file_put_contents($logFile, $logMessage, FILE_APPEND);

            // Exemple 2 : Envoyer un email (optionnel)
            // Remplacez l'adresse email ci-dessous par votre propre adresse
            $to = 'votreemail@domaine.com';
            $subject = 'Nouveau message depuis le formulaire de contact';
            $emailMessage = "Nom: $name\nEmail: $email\nMessage: $message\n";
            $headers = "From: $email";

            // Utilisez mail() pour envoyer l'email (si configuré sur votre serveur)
            // mail($to, $subject, $emailMessage, $headers);

            // Rediriger vers la page contact avec un message de succès
            header('Location: contact.php?status=success');
            exit;
        } else {
            // Rediriger avec un message d'erreur si l'email n'est pas valide
            header('Location: contact.php?status=error&message=email_invalid');
            exit;
        }
    } else {
        // Rediriger avec un message d'erreur si des champs sont vides
        header('Location: contact.php?status=error&message=fields_empty');
        exit;
    }
} else {
    // Rediriger si l'utilisateur accède directement à ce fichier
    header('Location: contact.php');
    exit;
}
