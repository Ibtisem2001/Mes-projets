<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style/footer.css?v=102"/>
    <title>Footer et Cookies</title>
</head>
<body>

<!-- Contenu principal -->
<footer class="footer">
    <p>
        &copy; 2024 WebCourses. Tous droits réservés. <br>
        <a href="mentions_legalesv2.pdf" target="_blank">Mentions légales</a> - 
        <a href="politique_de_confidentialite.pdf" target="_blank">Politique de confidentialité</a> - 
        <a href="gestion_des_cookies.pdf" target="_blank">Gestion des cookies</a> - 
        <a href="droitimage.pdf" target="_blank">Droit à l'image</a>
    </p>
</footer>

<!-- Bannière de cookies -->
<div class="cookie-banner" id="cookie-banner">
    <div class="cookie-content">
        <img src="image/cookie-icon.png" alt="Cookie Icon" class="cookie-icon">
        <div class="cookie-text">
            <h3>Nous utilisons des cookies</h3>
            <p>Notre site utilise des cookies pour une meilleure expérience. En acceptant, vous acceptez nos termes.</p>
        </div>
        <div class="cookie-buttons">
            <button id="accept-cookies" class="btn-cookie">Tout accepter</button>
            <button id="manage-cookies" class="btn-manage">Gérer les cookies</button>
            <button id="refuse-cookies" class="btn-refuse">Tout refuser</button>
        </div>
    </div>
</div>

<!-- JavaScript pour gérer la bannière -->
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const cookieBanner = document.getElementById("cookie-banner");
        const acceptBtn = document.getElementById("accept-cookies");
        const refuseBtn = document.getElementById("refuse-cookies");

        if (!localStorage.getItem("cookiesDecision")) {
            cookieBanner.style.display = "flex";
        }

        acceptBtn.addEventListener('click', function () {
            localStorage.setItem("cookiesDecision", "accepted");
            cookieBanner.style.display = "none";
        });

        refuseBtn.addEventListener('click', function () {
            localStorage.setItem("cookiesDecision", "refused");
            cookieBanner.style.display = "none";
        });
    });
</script>

</body>
</html>