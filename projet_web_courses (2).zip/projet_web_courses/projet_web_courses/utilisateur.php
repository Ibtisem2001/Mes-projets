<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php'; // Inclure la connexion MySQLi

echo "Le fichier utilisateurs.php est bien chargé !";

// Définition du filtre
$where = "";
$params = [];

// Vérifier si un filtre "niveau" est appliqué
if (!empty($_GET['niveau'])) {
    $where = "WHERE niveau = ?";
    $params[] = $_GET['niveau'];
}

// Construire la requête SQL avec un filtre optionnel
$sql = "SELECT nom, email, niveau FROM users $where";

// Si un filtre est appliqué, on prépare la requête
if (!empty($params)) {
    $stmt = $db->prepare($sql);
    $stmt->bind_param("s", $params[0]); // "s" = string
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $db->query($sql);
}

// Vérifier si la requête a bien fonctionné
if (!$result) {
    die("Erreur dans la requête SQL : " . $db->error);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Utilisateurs</title>
    <style>
        table {
            width: 50%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Liste des Utilisateurs</h2>

<!-- Formulaire de filtrage en dehors du tableau -->
<form method="GET">
    <select name="niveau">
        <option value="">Tous</option>
        <option value="Débutant" <?= (!empty($_GET['niveau']) && $_GET['niveau'] == 'Débutant') ? 'selected' : ''; ?>>Débutant</option>
        <option value="Intermédiaire" <?= (!empty($_GET['niveau']) && $_GET['niveau'] == 'Intermédiaire') ? 'selected' : ''; ?>>Intermédiaire</option>
        <option value="Avancé" <?= (!empty($_GET['niveau']) && $_GET['niveau'] == 'Avancé') ? 'selected' : ''; ?>>Avancé</option>
    </select>
    <button type="submit">Filtrer</button>
</form>

<table>
    <tr>
        <th>Nom</th>
        <th>Email</th>
        <th>Niveau</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= htmlspecialchars($row['nom']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['niveau']) ?></td>
        </tr>
    <?php } ?>
</table>

</body>
</html>
