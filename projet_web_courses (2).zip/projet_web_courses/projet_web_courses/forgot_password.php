<?php
include('connexion_db.php'); // Inclure la connexion à la base de données

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = htmlspecialchars($_POST['email']);

    // Vérifier que l'email est valide
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Générer un token unique
        $token = bin2hex(random_bytes(32));

        // Insérer le token dans la base avec l'email et une date d'expiration
        $stmt = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))");
        $stmt->bind_param('ss', $email, $token);
        $stmt->execute();

        // Lien de réinitialisation
        $resetLink = "http://localhost/projet_web_courses/reset_password.php?token=$token";

        // Message avec un bouton propre
        $message = "Un email avec un lien de réinitialisation a été envoyé. <a href='$resetLink' class='reset-link'>Cliquez ici pour réinitialiser votre mot de passe</a>.";
    } else {
        $message = "Veuillez saisir une adresse email valide.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mot de passe oublié</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f9f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 100%;
            max-width: 400px;
        }
        .form-container img {
            max-width: 80px;
            margin-bottom: 20px;
        }
        .form-container h1 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .form-container .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        .form-container input {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            width: 100%;
        }
        .form-container button {
            background-color: #E8A0BC;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        .form-container .confirmation-message {
            font-size: 14px;
            color: #28a745; /* Vert pour succès */
            margin-bottom: 20px;
        }
        .form-container .error-message {
            font-size: 14px;
            color: #dc3545; /* Rouge pour erreur */
            margin-bottom: 20px;
        }
        /* Lien de réinitialisation stylé */
        .reset-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .reset-link:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <img src="image/r.jpg" alt="Logo">
        <h1>Mot de passe oublié</h1>

        <!-- Message de confirmation ou d'erreur -->
        <?php if (!empty($message)): ?>
            <?php if (strpos($message, 'envoyé') !== false): ?>
                <p class="confirmation-message"><?php echo $message; ?></p>
            <?php else: ?>
                <p class="error-message"><?php echo $message; ?></p>
            <?php endif; ?>
        <?php endif; ?>

        <form action="forgot_password.php" method="POST">
            <div class="form-group">
                <label for="email">Adresse email</label>
                <input type="email" id="email" name="email" placeholder="exemple@domaine.com" required>
            </div>
            <button type="submit">Recevoir le lien</button>
        </form>
    </div>
</body>
</html>
