<?php
include('connexion_db.php'); // Connexion à la base de données

// Initialiser les variables pour les messages
$message = '';
$token = $_GET['token'] ?? null;

// Vérifier si le token est présent dans l'URL
if ($token) {
    // Vérifier si le token existe et qu'il n'a pas expiré
    $stmt = $conn->prepare("SELECT email FROM password_resets WHERE token = ? AND expires_at > NOW()");
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $email = $row['email'];

        // Si le formulaire est soumis
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $new_password = htmlspecialchars($_POST['password']);
            $confirm_password = htmlspecialchars($_POST['confirm_password']);

            // Vérifier si les mots de passe correspondent
            if ($new_password === $confirm_password) {
                // Hashage du nouveau mot de passe
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                // Mettre à jour le mot de passe de l'utilisateur
                $stmt = $conn->prepare("UPDATE users SET mot_de_passe = ? WHERE email = ?");
                $stmt->bind_param('ss', $hashed_password, $email);
                $stmt->execute();

                // Supprimer le token après réinitialisation
                $stmt = $conn->prepare("DELETE FROM password_resets WHERE token = ?");
                $stmt->bind_param('s', $token);
                $stmt->execute();

                // Redirection avec message de succès
                header("Location: connexion.php?message=reset_success");
                exit;
            } else {
                $message = "Les mots de passe ne correspondent pas.";
            }
        }
    } else {
        die("Le lien de réinitialisation est invalide ou expiré.");
    }
} else {
    die("Token manquant.");
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation du mot de passe</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f9f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 100%;
            max-width: 400px;
        }
        .form-container img {
            max-width: 80px;
            margin-bottom: 20px;
        }
        .form-container h1 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .form-container .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        .form-container input {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            width: 100%;
        }
        .form-container button {
            background-color: #E8A0BC;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        .form-container .confirmation-message {
            font-size: 14px;
            color: #28a745; /* Vert pour succès */
            margin-bottom: 20px;
        }
        .form-container .error-message {
            font-size: 14px;
            color: #dc3545; /* Rouge pour erreur */
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <img src="image/r.jpg" alt="Logo">
        <h1>Réinitialiser votre mot de passe</h1>

        <!-- Message de confirmation ou d'erreur -->
        <?php if (!empty($message)): ?>
            <p class="<?php echo strpos($message, 'succès') !== false ? 'confirmation-message' : 'error-message'; ?>">
                <?php echo $message; ?>
            </p>
        <?php endif; ?>

        <form action="reset_password.php?token=<?php echo htmlspecialchars($token); ?>" method="POST">
            <div class="form-group">
                <label for="password">Nouveau mot de passe</label>
                <input type="password" id="password" name="password" placeholder="Entrez un nouveau mot de passe" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirmez le mot de passe</label>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirmez le mot de passe" required>
            </div>
            <button type="submit">Réinitialiser</button>
        </form>
    </div>
</body>
</html>
