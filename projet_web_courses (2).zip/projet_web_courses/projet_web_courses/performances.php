<?php
require 'db.php'; // Connexion à la base de données

$query = "
    SELECT 
        p.id, 
        u.nom AS user_name, 
        e.name AS event_name, 
        e.date AS event_date, 
        p.time, 
        p.ranking 
    FROM performances p
    JOIN users u ON p.user_id = u.id
    JOIN events e ON p.event_id = e.id
    ORDER BY p.ranking ASC;
";

$result = $db->query($query);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Performances des Utilisateurs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #deb4d2;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            margin: 30px auto;
            max-width: 1000px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th {
            background-color: #deb4d2;
            color: white;
            text-align: center;
            padding: 10px;
        }
        table td {
            text-align: center;
            padding: 10px;
        }
        table tbody tr:hover {
            background-color: #f8f9fa;
        }
        .badge {
            font-size: 0.9rem;
            padding: 5px 10px;
            border-radius: 10px;
        }
        .badge.gold { background-color: gold; color: black; }
        .badge.silver { background-color: silver; color: black; }
        .badge.bronze { background-color: #cd7f32; color: white; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Performances des Utilisateurs</h1>
    </div>

    <div class="container">
        <?php if ($result->num_rows > 0): ?>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Utilisateur</th>
                        <th>Événement</th>
                        <th>Date</th>
                        <th>Temps</th>
                        <th>Classement</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['user_name']) ?></td>
                            <td><?= htmlspecialchars($row['event_name']) ?></td>
                            <td><?= htmlspecialchars($row['event_date']) ?></td>
                            <td><?= htmlspecialchars($row['time']) ?></td>
                            <td>
                                <?php if ($row['ranking'] == 1): ?>
                                    <span class="badge gold">1er</span>
                                <?php elseif ($row['ranking'] == 2): ?>
                                    <span class="badge silver">2ème</span>
                                <?php elseif ($row['ranking'] == 3): ?>
                                    <span class="badge bronze">3ème</span>
                                <?php else: ?>
                                    <?= htmlspecialchars($row['ranking']) ?>ème
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-center">Aucune performance enregistrée pour le moment.</p>
        <?php endif; ?>
    </div>
</body>
</html>
