<?php
$host = 'localhost';
$dbname = 'appliwebcourses'; // Nom de la base de données
$username = 'root'; // Nom d'utilisateur
$password = 'root'; // Changez en fonction de votre configuration

try {
    $db = new mysqli($host, $username, $password, $dbname);
    if ($db->connect_error) {
        die("Erreur de connexion : " . $db->connect_error);
    }
    echo "Connexion réussie à la base de données.";
} catch (Exception $e) {
    die("Erreur : " . $e->getMessage());
}
?>
