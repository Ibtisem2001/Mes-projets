<?php
// Connexion à la base de données
$host = 'localhost';
$username = 'root';
$password = 'root';
$dbname = 'appliwebcourses';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Requête pour récupérer les données
$sql = "SELECT * FROM courses";

if (empty($sql)) {
    die("La requête SQL est vide.");
}

$result = $conn->query($sql);

// Vérification et retour
$courses = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $courses[] = $row;
    }
}

$conn->close();
?>
