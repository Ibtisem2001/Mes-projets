<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Information club - WebCourses</title>
    
    <!-- Liens vers les styles -->
    <link rel="stylesheet" href="style_global.css?v=105">
    <link rel="stylesheet" href="style_home.css?v=105">
    <link rel="stylesheet" href="style.css?v=105">
    <link rel="stylesheet" href="style/info_club.css?v=105">
</head>
<body>

<?php include('header.php'); ?>

<nav>
    <ul>
        <li><a href="index1.php">Accueil</a></li>
        <li><a href="qui_sommes_nous.php">Qui sommes-nous ?</a></li>
        <li><a href="calendrier_evenementiel.php">Calendrier évènementiel</a></li>
        <li><a href="info_club.php">Informations Club</a></li>
        
        <?php if (isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] === true) { ?>
            <li><a href="deconnexion.php" class="btn-deconnexion">Déconnexion</a></li>
        <?php } ?>
    </ul>
</nav>

<p id="vie"><strong><u>La vie des clubs :</u></strong></p>

<p id="choisir">Choisir son club sous forme de liste venant de la base de données :</p>

<label for="club-select">Choix du club:</label>
<select name="club" id="club-select">
    <option value="">--Choisissez une option--</option>
    <option value="club1">Club 1</option>
    <option value="club2">Club 2</option>
    <option value="club3">Club 3</option>
</select>

<p id="nombre">Afficher : le nombre d'adhérents pour l'année en cours</p>
<p id="club">L'historique du classement du club (année / classement)</p>

<footer>
    <p id="footer">
        &copy; <a href="mentions_legalesv2.pdf" target="_blank">Mentions légales</a> - 
        <a href="politique_de_confidentialite.pdf" target="_blank">Politique de confidentialité</a> - 
        <a href="gestion_des_cookies.pdf" target="_blank">Gestion des cookies</a> - 
        <a href="droitimage.pdf" target="_blank">Droit à l'image</a>
    </p>
</footer>

</body>
</html>
