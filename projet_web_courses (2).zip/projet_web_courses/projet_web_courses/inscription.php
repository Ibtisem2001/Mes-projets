<?php
// Activer les erreurs pour le débogage
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

// Démarrer la session
session_start();

// Connexion à la base de données
try {
    $conn = new PDO("mysql:host=localhost;dbname=appliwebcourses", "root", "root");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Initialisation du message
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données du formulaire et vérifier leur existence
    $nom = isset($_POST['nom']) ? trim($_POST['nom']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $mot_de_passe = isset($_POST['mot_de_passe']) ? $_POST['mot_de_passe'] : '';
    $confirmation_mot_de_passe = isset($_POST['confirmation_mot_de_passe']) ? $_POST['confirmation_mot_de_passe'] : '';

    // Vérifier que tous les champs sont remplis
    if (!empty($nom) && !empty($email) && !empty($mot_de_passe) && !empty($confirmation_mot_de_passe)) {
        // Vérifier que les mots de passe correspondent
        if ($mot_de_passe !== $confirmation_mot_de_passe) {
            $message = "Les mots de passe ne correspondent pas.";
        } else {
            // Vérifier si l'email existe déjà dans la base de données
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email");
            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                $message = "Cet email est déjà utilisé.";
            } else {
                // Hasher le mot de passe
                $hashed_password = password_hash($mot_de_passe, PASSWORD_DEFAULT);

                // Insérer le nouvel utilisateur dans la base de données
                $stmt = $conn->prepare("INSERT INTO users (nom, email, password, date_inscription) VALUES (:nom, :email, :mot_de_passe, NOW())");
                $stmt->execute([
                    'nom' => $nom,
                    'email' => $email,
                    'mot_de_passe' => $hashed_password,
                ]);

                // Créer une session utilisateur
                $_SESSION['user_id'] = $conn->lastInsertId(); // Récupérer l'ID de l'utilisateur nouvellement inscrit

                // Rediriger vers la page d'accueil (index1.php)
                header("Location: index1.php");
                exit;
            }
        }
    } else {
        $message = "Tous les champs sont requis.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        h1 {
            color: #333;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            gap: 15px;
            max-width: 400px;
            width: 100%;
        }
        input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        button {
            padding: 10px;
            background-color: #E8A0BC;
            border: none;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            font-size: 1rem;
            cursor: pointer;
        }
        button:hover {
            background-color: #d18aa4;
        }
        a {
            color: #E8A0BC;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .message {
            color: red;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }
        .message.success {
            color: green;
        }
    </style>
</head>
<body>
    <h1>Inscription</h1>
    <?php if (!empty($message)): ?>
        <p class="message <?php echo strpos($message, 'réussie') !== false ? 'success' : ''; ?>">
            <?php echo htmlspecialchars($message); ?>
        </p>
    <?php endif; ?>
    <form method="POST" action="">
     
    <input type="text" id="nom" name="nom" placeholder="Nom" required>
   
    <input type="email" name="email" placeholder="Email" required>
    
    <input type="password" name="mot_de_passe" placeholder="Mot de passe" required>
     <input type="password" name="confirmation_mot_de_passe" placeholder="Confirmez le mot de passe" required>
   
    <button type="submit">S'inscrire</button>
    <br/>
    </form>
    <p>Déjà inscrit ? <a href="connexion.php">Connectez-vous</a>.</p>
    

</body>
</html>
