<footer>
    <p>&copy; 2024 Barko Confection - Créé avec passion et raffinement.</p>
    <p><a href="contact.php">Contactez-nous</a> pour en savoir plus.</p>
</footer>
