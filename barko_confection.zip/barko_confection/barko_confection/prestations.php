<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nos Prestations | Barko Confection</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <style>
        /* Styles globaux */
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #000;
            color: #fff;
            overflow-x: hidden;
        }

        /* Header */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: #000;
            border-bottom: 1px solid #333;
        }

        header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5em;
            color: #fff;
            font-weight: 700;
            letter-spacing: 2px;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            margin-left: 30px;
            font-size: 1.1em;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #e74c3c;
        }

        /* Section des prestations */
        .services-title {
            text-align: center;
            font-family: 'Playfair Display', serif;
            font-size: 3em;
            margin: 50px 0 20px;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }

        .services-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 40px;
            padding: 0 50px 50px;
        }

        .service-item {
            background: linear-gradient(145deg, #111, #1c1c1c);
            border: 1px solid #333;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.7);
            padding: 30px;
            text-align: center;
            transition: transform 0.4s, box-shadow 0.4s;
            position: relative;
            overflow: hidden;
        }

        .service-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 25px rgba(231, 76, 60, 0.5);
        }

        .service-item img {
            width: 80px;
            margin-bottom: 20px;
        }

        .service-item h3 {
            font-family: 'Playfair Display', serif;
            font-size: 1.7em;
            color: #fff;
            margin-bottom: 15px;
        }

        .service-item p {
            font-size: 1.1em;
            color: #ccc;
            line-height: 1.6;
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 20px;
            background-color: #000;
            color: #ccc;
            font-size: 0.9em;
            border-top: 1px solid #333;
        }

        footer a {
            color: #e74c3c;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        footer a:hover {
            color: #fff;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <h1>BARKO CONFECTION</h1>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="about.php">À propos</a>
            <a href="contact.php">Contact</a>
            <a href="prestations.php">Services</a>
        </nav>
    </header>

    <!-- Titre principal -->
    <h2 class="services-title">Nos Prestations</h2>

    <!-- Section des prestations -->
    <div class="services-container">
        <div class="service-item">
            <img src="images/jean.png" alt="Jean">
            <h3>Retouches Jeans</h3>
            <p>Des ajustements précis pour redonner vie à vos jeans préférés.</p>
        </div>
        <div class="service-item">
            <img src="images/manteau.png" alt="Manteau">
            <h3>Retouches Manteaux</h3>
            <p>Des manteaux ajustés avec élégance pour toutes les saisons.</p>
        </div>
        <div class="service-item">
            <img src="images/robe.png" alt="Robe">
            <h3>Retouches Robes</h3>
            <p>Transformez vos robes pour des occasions exceptionnelles.</p>
        </div>
        <div class="service-item">
            <img src="images/chemise.png" alt="Chemise">
            <h3>Retouches Chemises</h3>
            <p>Des chemises parfaitement taillées pour un style unique.</p>
        </div>
        <div class="service-item">
            <img src="images/veste.png" alt="Veste">
            <h3>Retouches Vestes</h3>
            <p>Des vestes personnalisées pour un ajustement parfait.</p>
        </div>
        <div class="service-item">
            <img src="images/costume.png" alt="Costume">
            <h3>Retouches Costumes</h3>
            <p>Un travail de précision pour des costumes d'exception.</p>
        </div>
    </div>
    

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Barko Confection - Créé avec passion et raffinement. <a href="contact.php">Contactez-nous</a></p>
    </footer>
</body>
</html>
