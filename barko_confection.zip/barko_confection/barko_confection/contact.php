<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact | Barko Confection</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <style>
        /* Styles globaux */
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #000;
            color: #fff;
            overflow-x: hidden;
        }

        /* Header */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: #000;
            border-bottom: 1px solid #333;
        }

        header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5em;
            color: #fff;
            font-weight: 700;
            letter-spacing: 2px;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            margin-left: 30px;
            font-size: 1.1em;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #e74c3c;
        }

        /* Section Contact */
        .contact-container {
            max-width: 900px;
            margin: 50px auto;
            padding: 50px;
            background: #111;
            border: 1px solid #444;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        .contact-container h2 {
            font-family: 'Playfair Display', serif;
            font-size: 3em;
            color: #fff;
            margin-bottom: 20px;
        }

        .contact-container p {
            font-size: 1.2em;
            color: #ccc;
            margin-bottom: 30px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        input, textarea {
            width: 100%;
            padding: 15px;
            border: 1px solid #444;
            border-radius: 5px;
            background-color: #222;
            color: #fff;
            font-size: 1em;
            transition: border 0.3s ease, box-shadow 0.3s ease;
        }

        input:focus, textarea:focus {
            border: 1px solid #e74c3c;
            box-shadow: 0 0 10px rgba(231, 76, 60, 0.7);
            outline: none;
        }

        button {
            padding: 15px;
            background-color: #fff;
            color: #000;
            font-size: 1.2em;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        button:hover {
            background-color: #e74c3c;
            color: #fff;
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 20px;
            background-color: #000;
            color: #ccc;
            border-top: 1px solid #333;
        }

        footer a {
            color: #e74c3c;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        footer a:hover {
            color: #fff;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <h1>BARKO CONFECTION</h1>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="about.php">À propos</a>
            <a href="contact.php">Contact</a>
            <a href="prestations.php">Services</a>
        </nav>
    </header>

    <!-- Section Contact -->
    <div class="contact-container">
        <h2>Contactez-nous</h2>
        <p>Vous avez une demande spécifique ou un projet en tête ? Remplissez le formulaire ci-dessous, et nous vous répondrons dans les plus brefs délais.</p>
        <form action="submit_contact.php" method="POST">
            <input type="text" name="name" placeholder="Votre nom complet" required>
            <input type="email" name="email" placeholder="Votre adresse e-mail" required>
            <textarea name="message" rows="6" placeholder="Votre message" required></textarea>
            <button type="submit">Envoyer</button>
        </form>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Barko Confection - Créé avec passion et raffinement. <a href="index.php">Retour à l'accueil</a></p>
    </footer>
</body>
</html>
