<?php
// Définir la langue par défaut (ici le français)
$lang_code = isset($_GET['lang']) ? $_GET['lang'] : 'fr';

// Inclure le fichier de langue correspondant
if ($lang_code == 'en') {
    include('lang_en.php');
} elseif ($lang_code == 'pt') {
    include('lang_pt.php');
} else {
    include('lang_fr.php');
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang_code; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $lang['title']; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* Styles globaux */
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #000;
            color: #fff;
            overflow-x: hidden;
        }

        /* Header */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 50px;
            background-color: #000;
        }

        header h1 {
            font-size: 2.5em;
            color: #ccc;
            font-weight: 600;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            margin-left: 20px;
            font-size: 1em;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #e74c3c;
        }

        /* Hero Section */
        .hero {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 50px 80px;
            background-color: #000;
        }

        .hero .content {
            max-width: 50%;
        }

        .hero .content h1 {
            font-size: 4em;
            color: #fff;
            margin-bottom: 20px;
        }

        .hero .content p {
            font-size: 1.2em;
            color: #ccc;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .hero img {
            max-width: 40%;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(255, 255, 255, 0.2);
        }

        .content strong {
            font-weight: bold;
        }

        /* Section Partenaires */
        .partners {
            background-color: #111;
            padding: 30px 20px;
            text-align: center;
        }

        .partners h2 {
            font-size: 2.5em;
            color: #fff;
            margin-bottom: 20px;
        }

        .partners-list {
            display: flex;
            justify-content: space-around;
            align-items: center;
            flex-wrap: nowrap;
            overflow: hidden;
            white-space: nowrap;
            padding: 10px 0;
            animation: scroll 15s linear infinite;
        }

        .partners-list p {
            font-size: 1.5em;
            color: #fff;
            margin: 0 50px;
            font-family: 'Times New Roman', serif;
            letter-spacing: 2px;
            display: inline-block;
        }

        @keyframes scroll {
            from {
                transform: translateX(100%);
            }
            to {
                transform: translateX(-100%);
            }
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 20px;
            background-color: #000;
            color: #ccc;
            font-size: 0.9em;
        }

        footer a {
            color: #e74c3c;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        footer a:hover {
            color: #fff;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <h1>BARKO CONFECTION</h1>
        <nav>
            <a href="index.php?lang=fr"><?php echo $lang['home']; ?></a>
            <a href="about.php?lang=fr"><?php echo $lang['about']; ?></a>
            <a href="contact.php?lang=fr"><?php echo $lang['contact']; ?></a>
            <a href="prestations.php?lang=fr"><?php echo $lang['service']; ?></a>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="content">
            <h1><?php echo $lang['hero_title']; ?></h1>
            <p>
                <?php echo $lang['hero_text1']; ?>
            </p>
            <p>
                <?php echo $lang['hero_text2']; ?>
            </p>
        </div>
        <img src="image/lola.jpg" alt="Couture" style="max-width: 40%; border-radius: 5px;">
    </section>

    <!-- Section Partenaires -->
    <section class="partners">
        <h2><?php echo $lang['partners']; ?></h2>
        <div class="partners-list">
            <p>DIOR</p>
            <p>Chanel</p>
            <p>Louis Vitton</p>
            <p>Gucci</p>
            <p>Hermes</p>
            <p>Balenciaga</p>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Barko Confection - Créé avec passion et raffinement. <a href="contact.php?lang=fr"><?php echo $lang['contact_us']; ?></a></p>
    </footer>
</body>
</html>
