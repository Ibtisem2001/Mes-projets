<header>
    <div>
        <h2>BARKO CONFECTION</h2>
    </div>
    <nav>
        <a href="index.php">Accueil</a>
        <a href="about.php">À propos</a>
        <a href="services.php">Prestations</a>
        <a href="contact.php">Contact</a>
    </nav>
</header>
