<?php
$lang = array(
    'title' => 'Página em Português',
    'welcome' => 'Bem-vindo ao nosso site!',
    'description' => 'Esta é uma página de demonstração.',
);
?>
