<?php
$lang = array(
    'title' => 'Page in English',
    'welcome' => 'Welcome to our site!',
    'description' => 'This is a demonstration page.',
);
?>
