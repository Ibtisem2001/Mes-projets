<?php
$lang = array(
    'title' => 'Barko Confection | Couture et Retouche',
    'home' => 'Accueil',
    'about' => 'À propos',
    'contact' => 'Contact',
    'service' => 'Service',
    'hero_title' => 'Couture et Retouche',
    'hero_text1' => 'Chez Barko Confection, nous mettons à votre service notre expertise et notre passion pour la retouche et la couture.',
    'hero_text2' => 'Ourlets, ajustements, remplacement de fermetures, doublures ou création de finitions élégantes.',
    'partners' => 'Nos Partenaires',
    'contact_us' => 'Contactez-nous',
);
?>
