<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>À Propos | Barko Confection</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <section class="about">
        <h2>À Propos de Nous</h2>
        <p>Depuis plusieurs années, Barko Confection s'associe aux grandes maisons de couture pour offrir des services de retouche et de confection sur-mesure.</p>
    </section>

    <?php include 'footer.php'; ?>
</body>
</html>
