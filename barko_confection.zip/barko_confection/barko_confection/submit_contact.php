<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Simule l'envoi d'un email
    echo "<h2>Merci, $name. Votre message a bien été envoyé.</h2>";
    echo "<p>Nous vous contacterons à l'adresse : $email</p>";
} else {
    header("Location: contact.php");
    exit;
}
?>
